print("hola, soy un programa en phyton")
print(2 + 3 * 4)
print(mensaje_secreto)
print("¿llegare a ejecutarme?")
