




lad1 = int(input("ingrese el primer lado: "))
lad2 = int(input("ingrese el segundo lado: "))
lad3 = int(input("ingrese el tercer lado: "))

if lad1 == lad2 and lad2 == lad3:
    print("es equilatero")
elif lad1 == lad2 or lad1 == lad3 or lad2 == lad3:
    print("es isosceles")
else:
    print("es escaleno")

