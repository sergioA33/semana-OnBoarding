nombre=str(input("ingrese su nombre:"))
edad=int(input("ingrese du edad: "))

print("su nombre es:",nombre )
print("su edad es:",edad )
if edad>=18:
    print("es mayor de edad ")
else:
    print("eres menor de edad ")
