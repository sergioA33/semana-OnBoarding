

saldo = 500000

print("1. consultar saldo")
print("2. retirar dinero")
print("3. depositar dinero")
print("4. salir")

opcion = int(input("elija una opcion: "))
if opcion == 1:
    print("su saldo es:", saldo)
elif opcion == 2:
    retiro = int(input("cuanto desea retirar: "))

    if retiro <= saldo:
        saldo = saldo - retiro
        print("retiro realizado")
        
        print("saldo actual:", saldo)
    else:
        print("no tiene suficiente dinero")
elif opcion == 3:
    deposito = int(input("cuanto desea depositar: "))
    saldo = saldo + deposito
    print("saldo actual:", saldo)
elif opcion == 4:
    print("gracias por utilizar el cajero")
else:
    print("opcion incorrecta")

