
edad = int(input("Ingresa tu edad: "))

if edad < 0:
    print("Edad no válida (no puede ser negativa)")
elif edad >= 18:
    print("Puedes ingresar al evento")
else:
    print("No puedes ingresar al evento")

