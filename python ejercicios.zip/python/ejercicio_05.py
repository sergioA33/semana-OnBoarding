

n1=int(input("ingrese el primer numero "));
n2=int(input("ingrese el segundo numero"));
if n1>n2:
    print("el numero uno es mayor")
elif n2>n1:
    print("el numero dos es mayor")
else:
     print("los numeros son iguales")