nota=int(input("ingrese una nota del 0 al 100:"));

if nota>=70 and nota<=100:
    print("aprobo")
elif nota>=0 and nota<70:
    print("reprobo")
else:
    print("error nota no valida")


