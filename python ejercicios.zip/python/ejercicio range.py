



nm = int(input("Ingrese un número: "))
suma = 0
for nm in range(1, nm + 1):
    suma = suma + nm
    print("La suma es", suma)

