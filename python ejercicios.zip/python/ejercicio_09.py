





preciocom = float(input("ingrese el precio de su compra: "))
if preciocom >= 200000:
    total = preciocom - (preciocom * 0.20)
elif preciocom  >= 100000:
    total = preciocom - (preciocom * 0.10)
elif preciocom <1000000:
    total=preciocom

print("total a pagar:",total)
    

