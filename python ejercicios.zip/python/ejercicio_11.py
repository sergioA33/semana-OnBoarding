temperatura=float(input("ingresa una temperatura:"))
if temperatura<10:
    print("el clima esta frio")

elif temperatura>10 and temperatura<25:
    print("el clima esta templado")
elif temperatura>25 and temperatura<35:
    print("el clima esta caluroro")
else:
    print("el clima esta muy caliente ")