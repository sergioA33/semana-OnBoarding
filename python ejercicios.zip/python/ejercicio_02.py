num1=float(input("ingrese el primer numero: "))
num2=float(input("ingrse el segundo numero:"))

suma = num1 + num2
resta = num1 - num2

print("la suma es:",suma)
print("la resta es:",resta)
 
if suma>=10:
    print("la suma es mayor o igual a 10 ")
else:
    print("la suma es menor o igual que 10")
