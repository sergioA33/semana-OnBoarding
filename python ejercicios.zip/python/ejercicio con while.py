numero=int(input("ingrese un numero:"))
while numero >=1:
  print("numero")
  numero=numero-1
print ("despegue")