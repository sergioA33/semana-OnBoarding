

num1 = float(input("ingrese un primer numero : "));
num2 = float(input("ingrse un segundo numero : "));

operacion = input("ingrese la operacion que desee hacer (+, -, *, /): ");

if operacion == "+":
    print("resultado :", num1 + num2)
elif operacion == "-":
    print("resultado :", num1 - num2)
elif operacion == "*":
    print("resultado:", num1 * num2)
elif operacion == "/":
    if num2 != 0:
        print("resultado :", num1 / num2)
    else:
        print("no se puede dividir entre cero ")
else:
    print("operacion no valida")